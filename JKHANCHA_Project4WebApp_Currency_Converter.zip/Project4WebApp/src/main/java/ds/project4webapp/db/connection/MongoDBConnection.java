/**
 * Author: JYOTI GIRDHARI KHANCHANDANI
 * ANDREW ID : JKHANCHA
 * Last Modified: November 21, 2024
 *
 * This class manages the connection to MongoDB and provides methods for
 * interacting with the database for the Currency Conversion App.
 * It handles storing log information, retrieving previous logs, and fetching all past entries.
 * NOTE : This code is generated with assistance from Perplexity AI and ChatGPT.
 */
package ds.project4webapp.db.connection;
import com.mongodb.client.*;
import com.mongodb.client.result.InsertOneResult;
import ds.project4webapp.model.LogInformation;
import org.bson.Document;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
public class MongoDBConnection {

    // MongoDB connection details
    /**
     * The MongoDB connection URI.
     */
    private static final String DATABASE_URI = "mongodb+srv://jkhancha:VarshaG1702@distributedproject.wsjs5.mongodb.net/?retryWrites=true&w=majority&appName=distributedProject"; // Adjust if needed
    /**
     * The name of the MongoDB database.
     */
    private static final String DATABASE_NAME = "CurrencyDB";
    /**
     * The name of the MongoDB collection.
     */
    private static final String COLLECTION_NAME = "LogInformation";
    private final MongoClient mongoClient;
    private final MongoDatabase database;
    private final MongoCollection<Document> collection;

    // Constructor: Initialize the connection
    public MongoDBConnection() {
        try {
            // Correct MongoClient initialization
            this.mongoClient = MongoClients.create(DATABASE_URI);

            // Access the database
            this.database = mongoClient.getDatabase(DATABASE_NAME);

            // Access the collection
            this.collection = database.getCollection(COLLECTION_NAME);

            System.out.println("Connected to MongoDB successfully!");
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to connect to MongoDB");
        }
    }

    public MongoCollection<Document> getCollection() {
        return this.collection;
    }

    /**
     * Converts LocalDateTime to Date for MongoDB compatibility.
     */
    private Date convertToDate(LocalDateTime localDateTime) {
        return localDateTime != null ? Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant()) : null;
    }
    /**
     * Stores a LogInformation object in MongoDB.
     * @param logInformation The LogInformation object to store
     * @return The ObjectId of the inserted document as a String
     * @throws RuntimeException if storing fails
     */
    public String storeLog(LogInformation logInformation) {
        try {
            //Convert LogInformation fields to a MongoDB Document
            Document document = new Document()
                    .append("status", logInformation.getStatus())
                    .append("requestTimestamp", logInformation.getRequestTimestamp())
                    .append("requestId", logInformation.getRequestId())
                    .append("requestReceivedTimestamp", convertToDate(logInformation.getRequestReceivedTimestamp()))
                    .append("processingTime", logInformation.getProcessingTime())
                    .append("baseCurrency", logInformation.getBaseCurrency())
                    .append("baseValue", logInformation.getBaseValue())
                    .append("targetCurrency", logInformation.getTargetCurrency())
                    .append("targetValue", logInformation.getTargetValue())
                    .append("unitConversionRate", logInformation.getUnitConversionRate())
                    .append("difference", logInformation.getDifference())
                    .append("previousTimestamp", convertToDate(logInformation.getPreviousTimestamp()))
                    .append("responseTimestamp", convertToDate(logInformation.getResponseTimestamp()))
                    .append("modelName", logInformation.getModelName())
                    .append("previousUnitConversionRate", logInformation.getPreviousUnitConversionRate())
                    .append("errorMessage", logInformation.getErrorMessage());

            // Insert the document into MongoDB
            InsertOneResult result = collection.insertOne(document);
            String objectId = result.getInsertedId().asObjectId().toString();

            System.out.println("Log stored successfully! " + objectId);

            return objectId;
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to store log in MongoDB");
        }
    }
    /**
     * Retrieves the previous log entry for a given currency pair.
     * @param baseCurrency The base currency
     * @param targetCurrency The target currency
     * @param currentTimestamp The current timestamp
     * @return LogInformation object of the previous log, or null if not found
     */
    public LogInformation getPreviousLog(String baseCurrency, String targetCurrency, LocalDateTime currentTimestamp) {
        Document query = new Document("baseCurrency", baseCurrency)
                .append("targetCurrency", targetCurrency)
                .append("status", "success")
                .append("requestReceivedTimestamp", new Document("$lt", convertToDate(currentTimestamp)));

        Document result = collection.find(query)
                .sort(new Document("requestReceivedTimestamp", -1)) // Sort by timestamp descending
                .first();

        if (result != null) {
            LogInformation log = new LogInformation();
            log.setBaseCurrency(result.getString("baseCurrency"));
            log.setTargetCurrency(result.getString("targetCurrency"));
            log.setRequestReceivedTimestamp(getDateTimeField("requestReceivedTimestamp", result));
            log.setBaseValue(result.getString("baseValue"));
            log.setTargetValue(result.getDouble("targetValue"));
            log.setUnitConversionRate(result.getDouble("unitConversionRate"));
            return log;
        }
        return null;
    }
    /**
     * Retrieves all past log entries from the database.
     * @return List of LogInformation objects
     */
    public List<LogInformation> getAllPastEntries () {
        List<Document> pastEntries = new ArrayList<>();
        try (MongoCursor<Document> cursor = collection.find().iterator()) {
            while (cursor.hasNext()) {
                pastEntries.add(cursor.next());
            }
        }

        List<LogInformation> logInfoList = new ArrayList<>();
        pastEntries.forEach(result -> {
            LogInformation log = new LogInformation();

            log.setStatus(result.getString("status"));
            log.setRequestId(result.getString("requestId"));
            log.setRequestTimestamp(result.getString("requestTimestamp"));
            log.setModelName(result.getString("modelName"));
            log.setBaseCurrency(result.getString("baseCurrency"));
            log.setTargetCurrency(result.getString("targetCurrency"));
            log.setBaseValue(result.getString("baseValue"));
            log.setTargetValue(result.getDouble("targetValue"));
            log.setUnitConversionRate(result.getDouble("unitConversionRate"));
            log.setPreviousUnitConversionRate(result.getDouble("previousUnitConversionRate"));
            log.setPreviousTimestamp(getDateTimeField("previousTimestamp", result));
            log.setDifference(result.getDouble("difference"));
            log.setRequestReceivedTimestamp(getDateTimeField("requestReceivedTimestamp", result));
            log.setResponseTimestamp(getDateTimeField("responseTimestamp", result));
            log.setProcessingTime(result.getLong("processingTime"));

            logInfoList.add(log);
        });

        return logInfoList;
    }

    /**
     *
     * @param dateFieldName
     * @param document
     * @return LocalDateTime instant of the date field
     */
    private LocalDateTime getDateTimeField(String dateFieldName, Document document) {
        return document.getDate(dateFieldName) != null ? document.getDate(dateFieldName).toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime() : null;
    }

    /**
     * Closes the MongoDB connection.
     */
    public void closeConnection() {
        if (mongoClient != null) {
            mongoClient.close();
            System.out.println("MongoDB connection closed.");
        }
    }
}

