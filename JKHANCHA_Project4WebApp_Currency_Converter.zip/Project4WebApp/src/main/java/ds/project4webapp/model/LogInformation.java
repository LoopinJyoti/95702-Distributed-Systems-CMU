/**
 * Author: JYOTI GIRDHARI KHANCHANDANI
 * ANDREW ID : JKHANCHA
        * Last Modified: November 21, 2024
        *
        * This class represents the log information stored in MongoDB for tracking
 * currency conversion requests and responses in the Currency Conversion App.
        * It encapsulates all relevant details about a conversion request, including
 * request parameters, response data, and processing information.
 * NOTE : This code is generated with assistance from Perplexity AI and ChatGPT.
 */
package ds.project4webapp.model;
import ds.project4webapp.model.request.MobileAppRequest;
import java.time.LocalDateTime;

/**
 * Model class to represent the log information stored in MongoDB
 * for tracking currency conversion requests and responses.
 */
public class LogInformation {

    private String requestId;                  // Unique ID for the request

    // Android request details
    private String modelName;                  // Name of the Android device model
    private String requestTimestamp;
    private String baseCurrency;               // Base currency (e.g., USD)
    private String baseValue;                  // Amount in the base currency
    private String targetCurrency;             // Target currency (e.g., INR)

    // Android response

    private double targetValue;                // Converted value in the target currency
    private double unitConversionRate;          // Conversion rate (unit conversion)
    private double previousUnitConversionRate;
    private LocalDateTime previousTimestamp; // Timestamp for the difference calculation
    private double difference;                 // Difference between current and previous conversion

    // Log parameters

    private String status;                     // e.g., success or failure
    private LocalDateTime responseTimestamp; // Timestamp of the request initiation
    private LocalDateTime requestReceivedTimestamp; // Timestamp when the request was received
    private Long processingTime;             // Time taken to process the request (e.g., "200ms")
    private String errorMessage;        // If status is Failure, reason would be here

    // Constructors
    public LogInformation() {
    }

    // Getters and Setters

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public String getModelName() {
        return modelName;
    }

    public void setModelName(String modelName) {
        this.modelName = modelName;
    }

    public String getRequestTimestamp() {
        return requestTimestamp;
    }

    public void setRequestTimestamp(String requestTimestamp) {
        this.requestTimestamp = requestTimestamp;
    }

    public LocalDateTime getRequestTimestampAsDateTime() {
        return LocalDateTime.parse(this.requestTimestamp, MobileAppRequest.formatter);
    }

    public String getBaseCurrency() {
        return baseCurrency;
    }

    public void setBaseCurrency(String baseCurrency) {
        this.baseCurrency = baseCurrency;
    }

    public String getBaseValue() {
        return baseValue;
    }

    public void setBaseValue(String baseValue) {
        this.baseValue = baseValue;
    }

    public double getBaseValueAsDouble() {
        return Double.parseDouble(baseValue);
    }

    public String getTargetCurrency() {
        return targetCurrency;
    }

    public void setTargetCurrency(String targetCurrency) {
        this.targetCurrency = targetCurrency;
    }

    public double getTargetValue() {
        return targetValue;
    }

    public void setTargetValue(double targetValue) {
        this.targetValue = targetValue;
    }

    public double getUnitConversionRate() {
        return unitConversionRate;
    }

    public void setUnitConversionRate(double unitConversionRate) {
        this.unitConversionRate = unitConversionRate;
    }

    public double getPreviousUnitConversionRate() {
        return previousUnitConversionRate;
    }

    public void setPreviousUnitConversionRate(double previousUnitConversionRate) {
        this.previousUnitConversionRate = previousUnitConversionRate;
    }

    public LocalDateTime getPreviousTimestamp() {
        return previousTimestamp;
    }

    public void setPreviousTimestamp(LocalDateTime previousTimestamp) {
        this.previousTimestamp = previousTimestamp;
    }

    public double getDifference() {
        return difference;
    }

    public void setDifference(double difference) {
        this.difference = difference;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDateTime getResponseTimestamp() {
        return responseTimestamp;
    }

    public void setResponseTimestamp(LocalDateTime responseTimestamp) {
        this.responseTimestamp = responseTimestamp;
    }

    public LocalDateTime getRequestReceivedTimestamp() {
        return requestReceivedTimestamp;
    }

    public void setRequestReceivedTimestamp(LocalDateTime requestReceivedTimestamp) {
        this.requestReceivedTimestamp = requestReceivedTimestamp;
    }

    public Long getProcessingTime() {
        return processingTime;
    }

    public void setProcessingTime(Long processingTime) {
        this.processingTime = processingTime;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    @Override
    public String toString() {
        return "LogInformation{" +
                "requestId='" + requestId + '\'' +
                ", modelName='" + modelName + '\'' +
                ", requestTimestamp=" + requestTimestamp +
                ", baseCurrency='" + baseCurrency + '\'' +
                ", baseValue=" + baseValue +
                ", targetCurrency='" + targetCurrency + '\'' +
                ", targetValue=" + targetValue +
                ", unitConversionRate=" + unitConversionRate +
                ", previousUnitConversionRate=" + previousUnitConversionRate +
                ", previousTimestamp=" + previousTimestamp +
                ", difference=" + difference +
                ", status='" + status + '\'' +
                ", responseTimestamp=" + responseTimestamp +
                ", requestReceivedTimestamp=" + requestReceivedTimestamp +
                ", processingTime='" + processingTime + '\'' +
                ", errorMessage='" + errorMessage + '\'' +
                '}';
    }
}
