/**
 * Author: JYOTI GIRDHARI KHANCHANDANI
 * ANDREW ID : JKHANCHA
 * Last Modified: November 21, 2024
 *
 * This class represents a request object for currency conversion using the Free Currency API.
 * It encapsulates the necessary information to construct an API request URL and store response details.
 *
 * NOTE : This code is generated with assistance from Perplexity AI and ChatGPT.
 */

package ds.project4webapp.model.request;
import java.time.LocalDateTime;

/**
 * Model class representing a currency conversion request.
 * This class includes methods to construct the API URL dynamically.
 */
public class FreeCurrencyAppRequest {

    // Base URL and API Key for the Free Currency API
    private static final String API_BASE_URL = "https://api.freecurrencyapi.com/v1/latest";
    /**
     * The API key for authenticating requests to the Free Currency API.
     */
    private static final String API_KEY = "fca_live_gFQEnIdq9qPhKGUgEgFtEHr9FyPWWDG8Me1bADqc";

    // Request metadata


    // Conversion details
    private String baseCurrency;
    private String targetCurrency; // Multiple target currencies can be specified
    private double baseValue;

    // Optional fields to store response details
    //Should this be here?
    private LocalDateTime responseTimestamp;
    private double[] targetValues; // To store calculated values for each target currency

    // Constructors
    public FreeCurrencyAppRequest() {
    }

    public FreeCurrencyAppRequest(LocalDateTime requestTimestamp, String baseCurrency, String[] targetCurrencies, double baseValue) {
        this.baseCurrency = baseCurrency;
        this.targetCurrency = targetCurrency;
        this.baseValue = baseValue;
    }

    // Getters and setters


    public String getBaseCurrency() {
        return baseCurrency;
    }

    public void setBaseCurrency(String baseCurrency) {
        this.baseCurrency = baseCurrency;
    }

    public String getTargetCurrency() {
        return targetCurrency;
    }

    public void setTargetCurrency(String targetCurrency) {
        this.targetCurrency = targetCurrency;
    }

    public double getBaseValue() {
        return baseValue;
    }

    public void setBaseValue(double baseValue) {
        this.baseValue = baseValue;
    }

    public LocalDateTime getResponseTimestamp() {
        return responseTimestamp;
    }

    public void setResponseTimestamp(LocalDateTime responseTimestamp) {
        this.responseTimestamp = responseTimestamp;
    }

    public double[] getTargetValues() {
        return targetValues;
    }

    public void setTargetValues(double[] targetValues) {
        this.targetValues = targetValues;
    }

    /**
     * Constructs the API URL using the base currency and target currencies.
     *
     * @return The complete API URL as a String.
     */
    public String constructApiUrl() {


        // Build the API URL
        return API_BASE_URL +
                "?apikey=" + API_KEY +
                "&currencies=" + targetCurrency +
                "&base_currency=" + baseCurrency;
    }

    @Override
    public String toString() {
        return "CurrencyConversionRequest{" +
                ", baseCurrency='" + baseCurrency + '\'' +
                ", targetCurrencies='" + String.join(",", targetCurrency) + '\'' +
                ", baseValue=" + baseValue +
                ", responseTimestamp=" + responseTimestamp +
                '}';
    }
}
