/**
 * Author: JYOTI GIRDHARI KHANCHANDANI
 * ANDREW ID : JKHANCHA
 * Last Modified: November 21, 2024
 *
 * This class represents a request object for currency conversion from a mobile application.
 * It encapsulates all the necessary information needed to process a currency conversion request.
 *
 * NOTE : This code is generated with assistance from Perplexity AI and ChatGPT.
 */
package ds.project4webapp.model.request;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class MobileAppRequest {
    /**
     * DateTimeFormatter used for parsing and formatting request timestamps.
     * The format is set to "dd-MM-yyyy, HH:mm:ss".
     */
    public static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy, HH:mm:ss");

    // Request metadata
    private String requestTimestamp;
    private String androidModel;
    // Conversion details
    private String baseCurrency;
    private String targetCurrency;
    private String baseValue;

    // Constructors
    public MobileAppRequest() {
    }

    // Getters and setters
    public String getRequestTimestamp() {
        return requestTimestamp;
    }

    public void setRequestTimestamp(String requestTimestamp) {
        this.requestTimestamp = requestTimestamp;
    }

    public String getAndroidModel() {
        return androidModel;
    }

    public void setAndroidModel(String androidModel) {
        this.androidModel = androidModel;
    }

    public String getBaseCurrency() {
        return baseCurrency;
    }

    public void setBaseCurrency(String baseCurrency) {
        this.baseCurrency = baseCurrency;
    }

    public String getTargetCurrency() {
        return targetCurrency;
    }

    public void setTargetCurrency(String targetCurrency) {
        this.targetCurrency = targetCurrency;
    }

    public String getBaseValue() {
        return baseValue;
    }

    public void setBaseValue(String baseValue) {
        this.baseValue = baseValue;
    }

    public double getBaseValueAsDouble() {
        return Double.parseDouble(this.baseValue);
    }

    public LocalDateTime getRequestTimestampAsDateTime() {
        return LocalDateTime.parse(this.requestTimestamp, formatter);
    }

    @Override
    public String toString() {
        return "MobileAppRequest{" +
                "requestTimestamp='" + requestTimestamp + '\'' +
                ", androidModel='" + androidModel + '\'' +
                ", baseCurrency='" + baseCurrency + '\'' +
                ", targetCurrency='" + targetCurrency + '\'' +
                ", baseValue='" + baseValue + '\'' +
                '}';
    }
}
