/**
 * Author: JYOTI GIRDHARI KHANCHANDANI
 * ANDREW ID : JKHANCHA
 * Last Modified: November 21, 2024
 *
 * This class represents the response object from the Free Currency API
 * for a specific base and target currency conversion.
 * It encapsulates the essential information returned by the API.
 *
 * NOTE : This code is generated with assistance from Perplexity AI and ChatGPT.
 */
package ds.project4webapp.model.response;

/**
 * Model class to represent the response from the Free Currency API
 * for a specific base and target currency conversion.
 */
public class FreeCurrencyAppResponse {

    // Base currency for the conversion
    private String baseCurrency;

    // Target currency for the conversion
    private String targetCurrency;

    // Converted value for the specified target currency
    private double conversionRate;

    // Getters and setters
    public String getBaseCurrency() {
        return baseCurrency;
    }

    public void setBaseCurrency(String baseCurrency) {
        this.baseCurrency = baseCurrency;
    }

    public String getTargetCurrency() {
        return targetCurrency;
    }

    public void setTargetCurrency(String targetCurrency) {
        this.targetCurrency = targetCurrency;
    }

    public double getConversionRate() {
        return conversionRate;
    }

    public void setConversionRate(double conversionRate) {
        this.conversionRate = conversionRate;
    }

    @Override
    public String toString() {
        return "CurrencyApiResponse{" +
                "baseCurrency='" + baseCurrency + '\'' +
                ", targetCurrency='" + targetCurrency + '\'' +
                ", conversionRate=" + conversionRate +
                '}';
    }
}

