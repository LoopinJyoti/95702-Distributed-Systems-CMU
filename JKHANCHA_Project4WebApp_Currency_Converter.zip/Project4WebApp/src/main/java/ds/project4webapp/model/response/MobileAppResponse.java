/**
 * Author: JYOTI GIRDHARI KHANCHANDANI
 * ANDREW ID : JKHANCHA
 *
 * Last Modified: November 21, 2024
 *
 * This class represents the response object for currency conversion sent to the mobile app.
 * It encapsulates all the necessary information about the conversion result and historical data.
 *
 * NOTE : This code is generated with assistance from Perplexity AI and ChatGPT.
 */

package ds.project4webapp.model.response;
import java.time.LocalDateTime;

/**
 * Model class to represent the currency conversion response sent to the mobile app.
 */
public class MobileAppResponse {

    // Base currency for the conversion
    private String baseCurrency;

    // Target currency for the conversion
    private String targetCurrency;

    // Value in the base currency
    private double baseCurrencyValue;

    // Converted value in the target currency
    private double targetCurrencyValue;

    private double unitConversionRate;
    private double previousUnitConversionRate;

    private LocalDateTime previousTimestamp;
    // Difference between the last conversion value and the current one
    private double difference;

    // Constructors
    public MobileAppResponse() {
    }

    public MobileAppResponse(String baseCurrency, String targetCurrency, double baseCurrencyValue, double targetCurrencyValue, double unitConversionRate, double difference) {
        this.baseCurrency = baseCurrency;
        this.targetCurrency = targetCurrency;
        this.baseCurrencyValue = baseCurrencyValue;
        this.targetCurrencyValue = targetCurrencyValue;
        this.unitConversionRate = unitConversionRate;
        this.difference = difference;
    }

    // Getters and setters
    public String getBaseCurrency() {
        return baseCurrency;
    }

    public void setBaseCurrency(String baseCurrency) {
        this.baseCurrency = baseCurrency;
    }

    public String getTargetCurrency() {
        return targetCurrency;
    }

    public void setTargetCurrency(String targetCurrency) {
        this.targetCurrency = targetCurrency;
    }

    public double getBaseCurrencyValue() {
        return baseCurrencyValue;
    }

    public void setBaseCurrencyValue(double baseCurrencyValue) {
        this.baseCurrencyValue = baseCurrencyValue;
    }

    public double getTargetCurrencyValue() {
        return targetCurrencyValue;
    }

    public void setTargetCurrencyValue(double targetCurrencyValue) {
        this.targetCurrencyValue = targetCurrencyValue;
    }

    public double getDifference() {
        return difference;
    }

    public void setDifference(double difference) {
        this.difference = difference;
    }

    public double getUnitConversionRate() {
        return unitConversionRate;
    }

    public void setUnitConversionRate(double unitConversionRate) {
        this.unitConversionRate = unitConversionRate;
    }

    public double getPreviousUnitConversionRate() {
        return previousUnitConversionRate;
    }

    public void setPreviousUnitConversionRate(double previousUnitConversionRate) {
        this.previousUnitConversionRate = previousUnitConversionRate;
    }

    public LocalDateTime getPreviousTimestamp() {
        return previousTimestamp;
    }

    public void setPreviousTimestamp(LocalDateTime previousTimestamp) {

        this.previousTimestamp = previousTimestamp;
    }

    @Override
    public String toString() {
        return "MobileAppCurrencyResponse{" +
                "baseCurrency='" + baseCurrency + '\'' +
                ", targetCurrency='" + targetCurrency + '\'' +
                ", baseCurrencyValue=" + baseCurrencyValue +
                ", targetCurrencyValue=" + targetCurrencyValue +
                ", unitConversion=" + unitConversionRate +
                ", previousUnitConversionRate=" + previousUnitConversionRate +
                ", previousTimestamp=" + previousTimestamp +
                ", difference=" + difference +
                '}';
    }
}

