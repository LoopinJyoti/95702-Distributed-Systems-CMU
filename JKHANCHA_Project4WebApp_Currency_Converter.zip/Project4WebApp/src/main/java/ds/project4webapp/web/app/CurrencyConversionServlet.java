/**
 * Author: JYOTI GIRDHARI KHANCHANDANI
 * ANDREW ID : JKHANCHA
 * Last Modified: November 21, 2024
 *
 * This program implements a Currency Conversion Servlet that handles POST requests
 * for currency conversion. It utilizes a free currency API to fetch real-time
 * exchange rates and performs the conversion. The servlet also logs the conversion
 * details and handles error cases.
 *
 * The servlet performs the following main tasks:
 * 1. Validates the incoming request
 * 2. Makes an API call to fetch the current exchange rate
 * 3. Calculates the converted amount
 * 4. Retrieves previous conversion data (if available)
 * 5. Logs the conversion details in MongoDB
 * 6. Sends the response back to the client
 *
 * The program demonstrates handling of JSON requests and responses, API integration,
 * database operations, and error handling in a web application context.
 *
 * NOTE : This code is generated with assistance from Perplexity AI and ChatGPT.
 */

// imports for servlet, JSON handling, MongoDB connection, and utility classes

package ds.project4webapp.web.app;
import com.google.gson.*;
import ds.project4webapp.db.connection.MongoDBConnection;
import ds.project4webapp.model.LogInformation;
import ds.project4webapp.model.request.FreeCurrencyAppRequest;
import ds.project4webapp.model.request.MobileAppRequest;
import ds.project4webapp.model.response.MobileAppResponse;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.jsoup.Connection;
import org.jsoup.Jsoup;
import java.io.BufferedReader;
import java.io.IOException;
import java.lang.reflect.Type;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Set;

@WebServlet("/api/currency-conversion")
public class CurrencyConversionServlet extends HttpServlet {
    private static final Gson servletGson = createCustomGson();
    private MongoDBConnection mongoDBConnection;

    /**
     * @return
     */
    private static Gson createCustomGson() {
        DateTimeFormatter formatter = MobileAppRequest.formatter;
        return new GsonBuilder()
                .registerTypeAdapter(LocalDateTime.class, new JsonDeserializer<LocalDateTime>() {
                    @Override
                    public LocalDateTime deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
                        return LocalDateTime.parse(json.getAsString(), formatter);
                    }
                })
                .registerTypeAdapter(LocalDateTime.class, new JsonSerializer<LocalDateTime>() {
                    @Override
                    public JsonElement serialize(LocalDateTime src, Type typeOfSrc, JsonSerializationContext context) {
                        return new JsonPrimitive(src.format(formatter));
                    }
                })
                .create();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        System.out.println("doGet Invalid HTTP POST METHOD ");
        response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
        response.getWriter().write("{\"error\":\"Invalid Input Request\"}");


    }
    /**
     * Handles POST requests for currency conversion.
     *
     * @param request  The HttpServletRequest object containing the client's request
     * @param response The HttpServletResponse object for sending the response
     * @throws ServletException If the request cannot be handled
     * @throws IOException      If an input or output error occurs
     */

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Set the response content type to JSON
        response.setContentType("application/json");
        System.out.println("Header String :" + request.getHeader("User-agent"));
        LocalDateTime requestReceivedTimestamp = LocalDateTime.now();
        if (mongoDBConnection == null) {
            mongoDBConnection = new MongoDBConnection();
        }
        try {
            StringBuilder jsonBuffer = new StringBuilder();
            try (BufferedReader reader = request.getReader()) {
                String line;
                while ((line = reader.readLine()) != null) {
                    jsonBuffer.append(line);
                }
            }
            // Parse JSON string using custom Gson

            String jsonString = jsonBuffer.toString();
            System.out.println("JSON Stringing"+ jsonString);


            MobileAppRequest appRequest = servletGson.fromJson(jsonString, MobileAppRequest.class);
            System.out.println("Constructed request object from parameters: " + appRequest);

            // Validate request
            String validationError = validateRequest(appRequest);
            if (!validationError.equals("")) {
                // Save validation error in logInformation
                LogInformation logInformation = new LogInformation();
                logInformation.setStatus("failure");
                logInformation.setRequestId("req-" + System.currentTimeMillis());
                logInformation.setRequestTimestamp(appRequest.getRequestTimestamp());
                logInformation.setBaseCurrency(appRequest.getBaseCurrency());
                logInformation.setTargetCurrency(appRequest.getTargetCurrency());
                logInformation.setBaseValue(appRequest.getBaseValue());
                logInformation.setErrorMessage(validationError);

                logInformation.setRequestReceivedTimestamp(requestReceivedTimestamp);

                mongoDBConnection.storeLog(logInformation);
                System.out.println("Validation failed. Log saved: " + logInformation);

                // Return error to the client
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                response.getWriter().write("{\"error\":\"" + validationError + "\"}");
                return;
            }


            System.out.println("Validation passed for request: " + appRequest);

            // Construct API URL
            FreeCurrencyAppRequest apiRequest = new FreeCurrencyAppRequest();
            apiRequest.setBaseCurrency(appRequest.getBaseCurrency());
            apiRequest.setTargetCurrency(appRequest.getTargetCurrency());
            apiRequest.setBaseValue(appRequest.getBaseValueAsDouble());

            String apiUrl = apiRequest.constructApiUrl();
            System.out.println("Constructed API URL: " + apiUrl);

            // Make the API call
            String apiResponse = makeApiCall(apiUrl);
            System.out.println("API Response: " + apiResponse);

            // Parse the API response to extract the conversion rate

// Parse the API response to extract the conversion rate
// Handle cases where the response doesn't contain the required fields
            try {
                JsonObject apiJsonResponse = new Gson().fromJson(apiResponse, JsonObject.class);

                // Check if "data" field is present in the response
                if (!apiJsonResponse.has("data")) {
                    // Check for "message" and "errors" fields indicating an error response
                    if (apiJsonResponse.has("message") && apiJsonResponse.has("errors")) {
                        String errorMessage = apiJsonResponse.get("message").getAsString();
                        JsonObject errorsObject = apiJsonResponse.getAsJsonObject("errors");
                        String detailedError = errorsObject.toString();
                        System.out.println("Error from 3rd Party API: " + errorMessage + " - Details: " + detailedError);
                    }

                    // Generic error if "data" is missing and no additional details are provided
                    throw new Exception("Error while fetching data from 3rd Party API. ");
                }

                // Get the "data" object
                JsonObject dataObject = apiJsonResponse.getAsJsonObject("data");

                // Check if the target currency exists in the "data" object
                if (!dataObject.has(appRequest.getTargetCurrency())) {
                    throw new Exception("Error while fetching data from 3rd Party API: Target currency '" + appRequest.getTargetCurrency() + "' not found.");
                }
            } catch (JsonParseException e) {
                throw new Exception("Invalid JSON response from the 3rd Party API.", e);
            }

            JsonObject apiJsonResponse = servletGson.fromJson(apiResponse, JsonObject.class);
            JsonObject dataObject = apiJsonResponse.getAsJsonObject("data");
            double conversionRate = dataObject.get(appRequest.getTargetCurrency()).getAsDouble();
            System.out.println("Parsed Conversion Rate: " + conversionRate);

            // Calculate the target currency value
            double targetCurrencyValue = appRequest.getBaseValueAsDouble() * conversionRate;
            System.out.println("Calculated Target Currency Value: " + targetCurrencyValue);

            MobileAppResponse appResponse = new MobileAppResponse();
            // Get the previous log information
            LogInformation previousLog = mongoDBConnection.getPreviousLog(
                    appRequest.getBaseCurrency(),
                    appRequest.getTargetCurrency(),
                    LocalDateTime.now()
            );

            if (previousLog != null) {
                System.out.println("Previous Log Found: " + previousLog);
                appResponse.setPreviousTimestamp(previousLog.getRequestReceivedTimestamp());
                appResponse.setDifference(conversionRate - previousLog.getUnitConversionRate());
                appResponse.setPreviousUnitConversionRate(previousLog.getUnitConversionRate());
            } else {
                System.out.println("No previous log found.");
                appResponse.setPreviousTimestamp(null);
                appResponse.setDifference(0);
            }

// Populate the MobileAppResponse object
            appResponse.setBaseCurrency(appRequest.getBaseCurrency());
            appResponse.setTargetCurrency(appRequest.getTargetCurrency());
            appResponse.setBaseCurrencyValue(appRequest.getBaseValueAsDouble());
            appResponse.setTargetCurrencyValue(targetCurrencyValue);
            appResponse.setUnitConversionRate(conversionRate);


            System.out.println("Constructed MobileAppResponse: " + appResponse);

            LocalDateTime responseTimestamp = LocalDateTime.now();
// Create and store log information
            LogInformation logInformation = new LogInformation();
            logInformation.setStatus("success");
            logInformation.setModelName(appRequest.getAndroidModel());
            logInformation.setRequestTimestamp(appRequest.getRequestTimestamp());
            logInformation.setRequestId("req-" + System.currentTimeMillis());
            logInformation.setRequestReceivedTimestamp(requestReceivedTimestamp);
            Duration duration = Duration.between(requestReceivedTimestamp, responseTimestamp);
            long millis = duration.toMillis();
            logInformation.setProcessingTime(millis);
            logInformation.setBaseCurrency(appRequest.getBaseCurrency());
            logInformation.setBaseValue(appRequest.getBaseValue());
            logInformation.setTargetCurrency(appRequest.getTargetCurrency());
            logInformation.setTargetValue(targetCurrencyValue);
            logInformation.setUnitConversionRate(conversionRate);
            logInformation.setResponseTimestamp(responseTimestamp);
            logInformation.setPreviousUnitConversionRate(appResponse.getUnitConversionRate());
            logInformation.setPreviousTimestamp(appResponse.getPreviousTimestamp());
            logInformation.setDifference(appResponse.getDifference());

// Connect to MongoDB and store the log
            String mongoDbID = mongoDBConnection.storeLog(logInformation);
            System.out.println("LogInformation stored in MongoDB: " + logInformation);
            System.out.println("Mongo DB ID Stored : " + mongoDbID);
// Send the response back to the Android app
            String jsonResponse = servletGson.toJson(appResponse, MobileAppResponse.class);
            response.getWriter().write(jsonResponse);
            System.out.println("Sent response back to Android app.");


        } catch (JsonParseException e) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            response.getWriter().write("{\"error\":\"Invalid JSON format.\"}");
            e.printStackTrace();
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            response.getWriter().write("{\"error\":\"An error occurred while processing the request.\"}");
            e.printStackTrace();
        } finally {
            mongoDBConnection.closeConnection();
            mongoDBConnection = null;
        }
    }

    /**
     * Validates the currency conversion request.
     *
     * @param request The MobileAppRequest object to validate
     * @return An empty string if the request is valid, otherwise a string containing error messages
     */
    private String validateRequest(MobileAppRequest request) {
        String errorMessage = "";
        Set<String> validCurrencies = Set.of(
                "EUR", "USD", "JPY", "BGN", "CZK", "DKK", "GBP", "HUF", "PLN", "RON", "SEK",
                "CHF", "ISK", "NOK", "HRK", "RUB", "TRY", "AUD", "BRL", "CAD", "CNY", "HKD",
                "IDR", "ILS", "INR", "KRW", "MXN", "MYR", "NZD", "PHP", "SGD", "THB", "ZAR"
        );

        if (request.getBaseCurrency() == null || !validCurrencies.contains(request.getBaseCurrency())) {

            errorMessage += "Invalid baseCurrency: " + request.getBaseCurrency() + ";";
        }

        if (request.getTargetCurrency() == null || !validCurrencies.contains(request.getTargetCurrency())) {
            errorMessage += " Invalid targetCurrency: " + request.getTargetCurrency() + ";";
        }

        try {
            if (request.getBaseValueAsDouble() <= 0) {
                errorMessage += " Invalid baseValue: " + request.getBaseValue() + ";";
            }
        } catch (NumberFormatException nfe) {
            errorMessage += " Invalid baseValue format: " + request.getBaseValue() + ";";
        }

        try {
            request.getRequestTimestampAsDateTime();
        } catch (DateTimeParseException dtpe) {
            errorMessage += " Invalid Request Timestamp format: " + request.getRequestTimestamp() + ";";
        }

        return errorMessage;
    }

    /**
     * Makes an API call to the free currency conversion service.
     *
     * @param apiUrl The URL of the API endpoint
     * @return The response body from the API call
     * @throws IOException If an I/O error occurs during the API call
     */

    private String makeApiCall(String apiUrl) throws IOException {
        System.out.println("Making API call to: " + apiUrl);

        Connection.Response response = Jsoup.connect(apiUrl)
                .ignoreContentType(true)
                .method(Connection.Method.GET)
                .execute();

        System.out.println("Free Currency API call successful. Response received.");
        return response.body();
    }

}