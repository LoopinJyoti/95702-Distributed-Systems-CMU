/**
 * Author: JYOTI GIRDHARI KHANCHANDANI
 * andrew ID : JKHANCHA
 * Last Modified: November 21, 2024
 *
 * This servlet handles requests for the dashboard of the Currency Conversion App.
 * It retrieves data from MongoDB, processes it to generate analytics, and forwards
 * the results to a JSP page for display.
 *
 * The servlet is mapped to the "/dashboard" URL pattern and extends HttpServlet.
 * NOTE : This code is generated with assistance from Perplexity AI and ChatGPT.
 */

package ds.project4webapp.web.dashboard;
import com.mongodb.client.MongoCollection;
import ds.project4webapp.db.connection.MongoDBConnection;
import ds.project4webapp.model.LogInformation;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.bson.Document;
import java.io.IOException;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@WebServlet("/dashboard")
public class DashboardServlet extends HttpServlet {
    private MongoDBConnection mongoDBConnection;

    @Override
    public void init() throws ServletException {
        mongoDBConnection = new MongoDBConnection();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            if (mongoDBConnection == null) {
                mongoDBConnection = new MongoDBConnection();
            }
            // Connect to MongoDB collection
            MongoCollection<Document> collection = mongoDBConnection.getCollection();

            // Fetch all past entries
            List<LogInformation> logInfoList = mongoDBConnection.getAllPastEntries();
            req.setAttribute("pastEntries", logInfoList);

            /*
             * Operational Analytics
             */

            // No. of Requests
            long totalRequests = logInfoList.size();
            req.setAttribute("totalRequests", String.valueOf(totalRequests));

            Map<String, Long> statusCounts = logInfoList.stream()
                    .collect(Collectors.groupingBy(LogInformation::getStatus, Collectors.counting()));

            long successRequests = statusCounts.getOrDefault("success", 0L);
            req.setAttribute("successRequests", String.valueOf(successRequests));

            long failedRequests = statusCounts.getOrDefault("failure", 0L);
            req.setAttribute("failedRequests", String.valueOf(failedRequests));

            long totalRequestsToday = logInfoList.stream()
                    .filter(record -> record.getRequestReceivedTimestamp() != null
                            ? record.getRequestReceivedTimestamp().toLocalDate().equals(LocalDate.now())
                            : false)
                    .collect(Collectors.toList()).size();

            req.setAttribute("totalRequestsToday", String.valueOf(totalRequestsToday));

            // Currency Analytics

            // group and count base-currency
            Map<String, Long> baseCurrencyCounts = logInfoList.stream()
                    .filter(log -> log.getBaseCurrency() != null && !log.getBaseCurrency().trim().isEmpty() && !"failure".equals(log.getStatus()))
                    .collect(Collectors.groupingBy(LogInformation::getBaseCurrency, Collectors.counting()));

            // Sort by count in descending order
            List<Map.Entry<String, Long>> baseCurrencies = baseCurrencyCounts.entrySet().stream()
                    .sorted((e1, e2) -> Long.compare(e2.getValue(), e1.getValue()))
                    .collect(Collectors.toList());

            // group and count target-currency
            Map<String, Long> targetCurrencyCounts = logInfoList.stream()
                    .filter(log -> log.getTargetCurrency() != null && !log.getTargetCurrency().trim().isEmpty() && !"failure".equals(log.getStatus()))
                    .collect(Collectors.groupingBy(LogInformation::getTargetCurrency, Collectors.counting()));

            // Sort by count in descending order
            List<Map.Entry<String, Long>> targetCurrencies = targetCurrencyCounts.entrySet().stream()
                    .sorted((e1, e2) -> Long.compare(e2.getValue(), e1.getValue()))
                    .collect(Collectors.toList());

            // Android Model Analytics

            // group and count android model names
            Map<String, Long> androidModelCounts = logInfoList.stream()
                    .filter(log -> log.getModelName() != null && !log.getModelName().trim().isEmpty() && !"failure".equals(log.getStatus()))
                    .collect(Collectors.groupingBy(LogInformation::getModelName, Collectors.counting()));

            // Sort by count in descending order
            List<Map.Entry<String, Long>> androidModelNames = androidModelCounts.entrySet().stream()
                    .sorted((e1, e2) -> Long.compare(e2.getValue(), e1.getValue()))
                    .collect(Collectors.toList());

            req.setAttribute("topBaseCurrencies", baseCurrencies);
            req.setAttribute("topTargetCurrencies", targetCurrencies);
            req.setAttribute("topAndroidModels", androidModelNames);

            // Forward to JSP
            req.getRequestDispatcher("/dashboard.jsp").forward(req, resp);

        } catch (Exception e) {
            e.printStackTrace();
            req.setAttribute("errorMessage", "There was some problem loading the page. Please try again later.");
            req.getRequestDispatcher("/dashboard.jsp").forward(req, resp);
        } finally {
            if (mongoDBConnection != null) {
                mongoDBConnection.closeConnection();
                mongoDBConnection = null;
            }
        }
    }
    /**
     * Cleans up resources when the servlet is being destroyed.
     * This method closes the MongoDB connection.
     */
    @Override
    public void destroy() {
        mongoDBConnection.closeConnection();
    }
}
