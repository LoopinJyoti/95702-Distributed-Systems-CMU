/*
 * Author: Jyoti Girdhari Khanchandani
 * Last Modified: September 22, 2024
 *
 * The `ImageDetails` class stores information related to the dog breed images retrieved from an external API.
 *
 * Key Features:
 * 1. Stores details such as the breed name, image URLs, and image count.
 * 2. Provides getters and setters to manage the image data and facilitate passing this information between the servlet and JSP.
 *
 * This class functions as a simple data model to encapsulate the details of the dog breed images retrieved from the API.
 */


package ds;


public class ImageDetails {
    private int arrayLength;
    private int randomNumber;
    private String randomUrl;

    public ImageDetails(int arrayLength, int randomNumber, String randomUrl) {
        this.arrayLength = arrayLength;
        this.randomNumber = randomNumber;
        this.randomUrl = randomUrl;
    }

    public int getArrayLength() {
        return arrayLength;
    }

    public int getRandomNumber() {
        return randomNumber;
    }

    public String getRandomUrl() {
        return randomUrl;
    }
}


