//CODE BY : JYOTI KHANCHANDANI
//ANDREW ID : JKHANCHA

// MODEL


/*
 * Author: Jyoti Girdhari Khanchandani
 * Last Modified: September 23, 2024
 *
 * The `dogBreedsModel` class handles scraping and processing data related to dog breeds.
 *
 * Key Steps:
 * 1. It provides methods to dynamically scrape breed facts and breed-specific images from the AKC website.
 * 2. The `getFacts` method returns a list of facts related to the breed, selected from the AKC breed-specific page.
 * 3. The `getImageUrl` method extracts the URL of the breed's image by targeting the 'data-src' or 'src' attribute of the breed's image element.
 *
 * This class demonstrates:
 * - Use of Selenium to scrape dynamic web content, including breed-specific images.
 * - Efficient web scraping methods to extract specific data based on user-selected breeds.
 *
 * Note: Ideas for dynamic image URL extraction using the `data-src` attribute were discussed and refined using ChatGPT.
 */



package ds;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import jakarta.servlet.http.HttpServletResponse;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class dogBreedsModel {

    public ImageDetails getRandomImageUrl(String breed) throws IOException {
        // Dog CEO API link for the specific breed
        String jsonLink = "https://dog.ceo/api/breed/" + breed + "/images";

        // Fetch the content from the URL using JSoup
        org.jsoup.Connection connection = Jsoup.connect(jsonLink).ignoreContentType(true); // Ensure JSoup doesn't attempt to parse it as HTML
        String jsonResponse = connection.execute().body();

        // Parse the JSON response using Gson
        Gson gson = new Gson();
        JsonObject jsonObject = JsonParser.parseString(jsonResponse).getAsJsonObject();

        // Get the array of URLs from the "message" key
        JsonArray messageArray = jsonObject.getAsJsonArray("message");

        // Convert the JsonArray to a String array
        String[] urlArray = gson.fromJson(messageArray, String[].class);

        // Generate a random number to select an image from the array
        Random random = new Random();
        int randomNumber = random.nextInt(urlArray.length);

        // Create and return the ImageDetails object containing the length, random number, and the random URL
        return new ImageDetails(urlArray.length, randomNumber, urlArray[randomNumber]);
    }


    // Method to scrape only the facts
    public List<String> getFacts(String breed) throws IOException {
        String akcLink = "https://www.akc.org/dog-breeds/" + breed + "/";
        List<String> facts = new ArrayList<>();
        WebDriver driver = null;

        try {
            // Set up EdgeDriver (or use any WebDriver you prefer)
            System.setProperty("webdriver.edge.driver", "C:\\SeleniumDriver\\msedgedriver.exe");
            EdgeOptions options = new EdgeOptions();
            options.addArguments("--headless"); // Run in headless mode
            driver = new EdgeDriver(options);

            driver.get(akcLink);

            // Scroll to the bottom of the page
            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("window.scrollTo(0, document.body.scrollHeight)");

            // Wait for the fact section to load
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("div.fact-slider__slide-content")));

            // Scrape facts from the page
            List<WebElement> slides = driver.findElements(By.cssSelector("div.fact-slider__slide-content"));
            for (WebElement slide : slides) {
                String factText = slide.getText().trim();
                if (!factText.isEmpty()) {
                    facts.add(factText);
                }
                if (facts.size() >= 7) break; // Stop after 7 facts
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (driver != null) {
                driver.quit();
            }
        }

        return facts;
    }


    public String getImageUrl(String breed) throws IOException {
        String akcLink = "https://www.akc.org/dog-breeds/" + breed + "/";
        String imageUrl = "";
        WebDriver driver = null;

        try {
            // Set up WebDriver (EdgeDriver or ChromeDriver)
            System.setProperty("webdriver.edge.driver", "C:\\SeleniumDriver\\msedgedriver.exe");
            EdgeOptions options = new EdgeOptions();
            options.addArguments("--headless"); // Run in headless mode
            driver = new EdgeDriver(options);

            // Navigate to the AKC breed page
            driver.get(akcLink);

            // Wait for the breed image container to load (adjust the CSS selector if needed)
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("div.side-by-side__poster img.lozad")));

            // Select the breed image
            WebElement imgElement = driver.findElement(By.cssSelector("div.side-by-side__poster img.lozad"));

            // Get the actual image URL from 'data-src' or similar attribute
            if (imgElement != null) {
                imageUrl = imgElement.getAttribute("data-src");  // Check if the 'data-src' attribute contains the actual URL

                // Fallback: If 'data-src' is not present, check 'src'
                if (imageUrl == null || imageUrl.isEmpty()) {
                    imageUrl = imgElement.getAttribute("src");
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (driver != null) {
                driver.quit();
            }
        }

        return imageUrl;
    }


}
