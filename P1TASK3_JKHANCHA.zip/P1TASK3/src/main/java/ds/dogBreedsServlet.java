//CODE BY : JYOTI KHANCHANDANI
//ANDREW ID : JKHANCHA

// CONTROLLER 1

/*
 * Author: Jyoti Girdhari Khanchandani
 * Last Modified: September 22, 2024
 *
 * This servlet is responsible for managing user interactions related to selecting and viewing dog breed images.
 *
 * Key Steps:
 * 1. The servlet handles GET requests where the user selects a dog breed.
 * 2. It communicates with an API to retrieve random images of the selected breed.
 * 3. The resulting images are displayed on the JSP page, along with the number of images fetched and the random selection.
 *
 * This servlet demonstrates:
 * - Interaction with external APIs to fetch breed images.
 * - Forwarding image URLs and associated data to the view (`akc.jsp`) for display.
 */

package ds;

import java.io.*;



import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;


@WebServlet(name = "dogBreeds", value = {"/dogBreed","/result", "/akc"})
public class dogBreedsServlet extends HttpServlet {
    private String message;
    dogBreedsModel dbm = null; //Model for Task3

    public void init() {

        dbm=new dogBreedsModel();
        message = "Hello World!";
    }
    // This servlet will reply to HTTP GET requests via this doGet method
    //  CONTROLLER
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {

        response.setContentType("text/html");

        String selection = request.getParameter("dogBreed");
        //Converting selection to lowercase to match the format of the api
        selection = selection.toLowerCase();
        System.out.println(selection);
        // The breed link : https://dog.ceo/api/breed/(breedName)/images

        try {
            // Get image details from the model
            ImageDetails imageDetails = dbm.getRandomImageUrl(selection);
            System.out.println("Selected Breed is"+ selection);
            System.out.println(imageDetails.getRandomUrl());
            System.out.println(imageDetails.getArrayLength());
            System.out.println(imageDetails.getRandomNumber());
            System.out.println(imageDetails.getRandomUrl());


            // Pass the data to the JSP
            request.setAttribute("selection", selection);
            request.setAttribute("arrayLength", imageDetails.getArrayLength());
            request.setAttribute("randomNumber", imageDetails.getRandomNumber());
            request.setAttribute("randomUrl", imageDetails.getRandomUrl());

            // Forward to the result page
            RequestDispatcher rdResult = request.getRequestDispatcher("/result.jsp");
            rdResult.forward(request, response);

        } catch (IOException e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Failed to retrieve breed details.");
        }
    }

//    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
//        response.setContentType("text/html");
//        try {
//                String selection = request.getParameter("dogBreed");
//                String[] selectedFacts = request.getParameterValues("fact");
//
//                // Get breed facts from the model
//                List<String> breedFacts = dbm.doScraping(selection);
//
//                // Pass the facts to the JSP
//                request.setAttribute("breedFacts", breedFacts);
//
//                // Forward to the result page (akc.jsp or another JSP that displays the facts)
//                RequestDispatcher rdResult = request.getRequestDispatcher("/akc.jsp");
//                rdResult.forward(request, response);
//
//            } catch (IOException e) {
//                e.printStackTrace();
//                response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Failed to retrieve breed facts.");
//            }
//        }
    public void destroy() {
    }
}