// CODE BY : JYOTI KHANCHANDANI
// ANDREW ID : JKHANCHA

/*

 * Author: Jyoti Girdhari Khanchandani
 * Last Modified: September 22, 2024
 *
 * This program demonstrates a basic web application that performs hashing of a user-provided message.
 * The hashing function is specified via a parameter passed from the client-side (using HTTP).
 * If no hashing function is provided by the client, the program defaults to the MD5 algorithm.
 *
 * The message is hashed using the specified algorithm, and the resulting digest is returned to the client
 * in two formats: hexadecimal and Base64 notation.
 *
 * Key Steps:
 * 1. The hashing algorithm is selected from a form input (hashfunction) or defaults to MD5 if not provided.
 * 2. The program uses the selected algorithm to create a MessageDigest object.
 * 3. The input message is passed to the MessageDigest, which computes the digest (hash value).
 * 4. The resulting digest is then converted to two formats:
 *    - Hexadecimal string
 *    - Base64 string
 * 5. These two outputs are forwarded to a JSP page to be displayed in the web browser.
 *
 * The program illustrates the use of Java's cryptography APIs and forwarding techniques
 * in web development using servlets and JSP. It also demonstrates how to handle
 * default values for parameters in web applications.
 */

package ds.p1task1;
import java.io.*;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

@WebServlet(name = "computeHashes", value = "/computeHashes")//webserverlet configured for this URL
public class ComputeHashesServlet extends HttpServlet {
    //POLYMORPHISM
    private String message;

    public void init() {
        message = "Please enter a string of text data you want to encrypt : ";
    }
    @Override
    //browser tells which method to client
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        response.setContentType("text/html");

//REFERENCE : https://www.tutorialspoint.com/java_cryptography/java_cryptography_message_digest.htm
// Set default hashing algorithm to MD5
        String hash = request.getParameter("hashfunction");
        if (hash == null || hash.isEmpty()) {
            hash = "MD5";  // Default to MD5 if no parameter is passed
        }
        System.out.println("Selected Hashing Algorithm: " + hash);

// Creating the MessageDigest object
        MessageDigest md = null;
        try {
            md = MessageDigest.getInstance(hash);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }

// Passing data to the created MessageDigest Object
        md.update(message.getBytes());

// Compute the message digest
        byte[] digest = md.digest();
        System.out.println(digest);

// Converting the byte array into HexString format
        StringBuffer hexString = new StringBuffer();
        for (int i = 0; i < digest.length; i++) {
            hexString.append(Integer.toHexString(0xFF & digest[i]));
        }
        System.out.println("Hex format: " + hexString.toString());

// Converting the byte array to Base64 format
        String base64String = Base64.getEncoder().encodeToString(digest);
        System.out.println("Base64 format: " + base64String);

// Send both hex and Base64 formats to the JSP
        String hexOutput = hexString.toString();
        String base64Output = base64String;

// Set the attributes to be passed to result.jsp
        request.setAttribute("hexOutput", hexOutput);
        request.setAttribute("base64Output", base64Output);

// Display the output in result.jsp
        RequestDispatcher rd = request.getRequestDispatcher("result.jsp");
        rd.forward(request, response);


    }
    public void destroy() {
    }
}