
// CODE BY : JYOTI KHANCHANDANI
// ANDREW ID : JKHANCHA

/*
 * Author: Jyoti Girdhari Khanchandani
 * Last Modified: September 22, 2024
 *
 * This servlet handles user input from a clicker-style web application.
 * Users select one of four options (A, B, C, or D) in response to a question. The servlet counts the responses
 * for each option and forwards the results to a JSP for display.
 *
 * Key Steps:
 * 1. The servlet receives a GET request with the user's answer to a question (via a radio button).
 * 2. Depending on the selected answer (A, B, C, or D), a corresponding counter is incremented.
 * 3. If the request path is "/getResults", the servlet forwards the current results (counters for all options)
 *    to a JSP page (`getResults.jsp`) to display the total number of responses for each option.
 * 4. If the request is for other paths, the servlet forwards the selected answer back to `index.jsp`,
 *    confirming that the user’s answer has been registered.
 * 5. The servlet maintains the total count of responses for each option during its lifecycle.
 *
 * The servlet demonstrates the use of:
 * - Handling form input via GET requests.
 * - Maintaining state with local variables (counterA, counterB, counterC, counterD).
 * - Request dispatching to forward data between servlets and JSP pages.
 *
 * This web application allows the instructor or students to see how many people selected each answer.
 */

package ds.p1task2;

import java.io.*;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

@WebServlet(name = "answers", value = {"/answers","/getResults"} )
public class AnswersServlet extends HttpServlet {

    private int counterA = 0;
    private int counterB = 0;
    private int counterC = 0;
    private int counterD = 0;

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        response.setContentType("text/html");

        String selection = request.getParameter("questionOne");
        System.out.println(selection);

        if ("A".equals(selection)) {
            counterA += 1;
        } else if ("B".equals(selection)) {
            counterB += 1;
        } else if ("C".equals(selection)) {
            counterC += 1;
        } else if ("D".equals(selection)) {
            counterD += 1;
        }

        String servletPath = request.getServletPath();

        if ("/getResults".equals(servletPath)) {
            // Set attributes
            request.setAttribute("outputA", counterA);
            request.setAttribute("outputB", counterB);
            request.setAttribute("outputC", counterC);
            request.setAttribute("outputD", counterD);

            // Check if all counters are zero
            boolean noResults = (counterA == 0 && counterB == 0 && counterC == 0 && counterD == 0);
            request.setAttribute("noResults", noResults);

            // Forward to getResults.jsp using absolute path
            RequestDispatcher rdResult = request.getRequestDispatcher("/getResults.jsp");
            rdResult.forward(request, response);

        } else {
            // Set attribute
            request.setAttribute("output", selection);
            // Forward to index.jsp
            RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
            rd.forward(request, response);
        }
    }

    public void destroy() {
    }
}

