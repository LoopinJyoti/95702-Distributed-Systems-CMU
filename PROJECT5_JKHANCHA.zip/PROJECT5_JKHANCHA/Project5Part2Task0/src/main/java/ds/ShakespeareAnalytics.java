/**
 * ShakespeareAnalytics
 *
 * Author: JYOTI GIRDHARI KHANCHANDANI
 * ANDREW ID : JKHANCHA
 * STUDENT033
 * * Last Modified: December 1st, 2024
 * This program performs text analytics on a Shakespeare play using Apache Spark.
 * It calculates various statistics such as line count, word count, distinct word count,
 * symbol count, distinct symbol count, and distinct letter count. Additionally, it
 * provides an interactive word search functionality.
 *
 * The program uses Spark's JavaRDD to efficiently process the text file and perform
 * distributed computations.
 *
 *NOTE : THIS CODE WAS GENERATED WITH ASSISTANCE FROM CLAUDE AND PERPLEXITY AI.
 *
 *
 */
package ds;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;

import java.util.Arrays;
import java.util.Scanner;

public class ShakespeareAnalytics {

    /**
     * The main method that orchestrates the Shakespeare analytics process.
     *
     * @param args Command line arguments. args[0] should contain the input file path.
     */
    public static void main(String[] args) {
        // Check if file is provided
        if (args.length == 0) {
            System.out.println("No files provided.");
            System.exit(0);
        }

        String fileName = args[0];

        // Create Spark configuration and context
        SparkConf sparkConf = new SparkConf().setMaster("local").setAppName("Shakespeare Analytics");
        JavaSparkContext sparkContext = new JavaSparkContext(sparkConf);

        // Read input file
        JavaRDD<String> inputFile = sparkContext.textFile(fileName);

        // Perform various analytics
        long lineCount = inputFile.count();
        long wordCount = countWords(inputFile);
        long distinctWordCount = countDistinctWords(inputFile);
        long symbolCount = countSymbols(inputFile);
        long distinctSymbolCount = countDistinctSymbols(inputFile);
        long distinctLetterCount = countDistinctLetters(inputFile);

        // Display all analytics together
        displayAnalytics(lineCount, wordCount, distinctWordCount, symbolCount, distinctSymbolCount, distinctLetterCount);

        // Perform interactive word search
        performInteractiveWordSearch(fileName);


    }

    /**
     * Counts the total number of words in the input file.
     *
     * @param inputFile JavaRDD containing the lines of the input file
     * @return The total number of words
     */
    private static long countWords(JavaRDD<String> inputFile) {
        JavaRDD<String> words = inputFile.flatMap(line -> Arrays.asList(line.split("[^a-zA-Z]+")));
        return words.filter(word -> !word.isEmpty()).count();
    }

    /**
     * Counts the number of distinct words in the input file.
     *
     * @param inputFile JavaRDD containing the lines of the input file
     * @return The number of distinct words
     */
    private static long countDistinctWords(JavaRDD<String> inputFile) {
        JavaRDD<String> words = inputFile.flatMap(line -> Arrays.asList(line.split("[^a-zA-Z]+")));
        return words.filter(word -> !word.isEmpty()).distinct().count();
    }

    /**
     * Counts the total number of symbols in the input file.
     *
     * @param inputFile JavaRDD containing the lines of the input file
     * @return The total number of symbols
     */
    private static long countSymbols(JavaRDD<String> inputFile) {
        return inputFile.flatMap(line -> Arrays.asList(line.split(""))).count();
    }

    /**
     * Counts the number of distinct symbols in the input file.
     *
     * @param inputFile JavaRDD containing the lines of the input file
     * @return The number of distinct symbols
     */
    private static long countDistinctSymbols(JavaRDD<String> inputFile) {
        return inputFile.flatMap(line -> Arrays.asList(line.split(""))).distinct().count();
    }

    /**
     * Counts the number of distinct letters in the input file.
     *
     * @param inputFile JavaRDD containing the lines of the input file
     * @return The number of distinct letters
     */
    private static long countDistinctLetters(JavaRDD<String> inputFile) {
        JavaRDD<String> letters = inputFile.flatMap(line -> Arrays.asList(line.split("")));
        return letters.filter(character -> character.matches("[a-zA-Z]")).distinct().count();
    }

    /**
     * Displays the analytics results.
     *
     * @param lineCount The total number of lines
     * @param wordCount The total number of words
     * @param distinctWordCount The number of distinct words
     * @param symbolCount The total number of symbols
     * @param distinctSymbolCount The number of distinct symbols
     * @param distinctLetterCount The number of distinct letters
     */
    private static void displayAnalytics(long lineCount, long wordCount, long distinctWordCount,
                                         long symbolCount, long distinctSymbolCount, long distinctLetterCount) {
        System.out.println("Number of lines: " + lineCount);
        System.out.println("Number of words: " + wordCount);
        System.out.println("Number of distinct words: " + distinctWordCount);
        System.out.println("Number of symbols: " + symbolCount);
        System.out.println("Number of distinct symbols: " + distinctSymbolCount);
        System.out.println("Number of distinct letters: " + distinctLetterCount);
    }

    /**
     * Performs an interactive word search on the input file.
     *
     * @param fileName The name of the input file
     */
    private static void performInteractiveWordSearch(String fileName) {
        // Create Spark configuration and context
        SparkConf sparkConf = new SparkConf().setMaster("local").setAppName("Interactive Word Search");
        JavaSparkContext sparkContext = new JavaSparkContext(sparkConf);

        // Read the input text file
        JavaRDD<String> inputFile = sparkContext.textFile(fileName);

        // Prompt the user to enter a word
        System.out.print("Enter a word to search for (case-sensitive): ");
        Scanner scanner = new Scanner(System.in);
        String searchWord = scanner.nextLine();

        // Find all lines containing the search word
        JavaRDD<String> matchingLines = inputFile.filter(line -> line.contains(searchWord));

        // Print the matching lines
        System.out.println("Lines containing the word \"" + searchWord + "\":");
        matchingLines.foreach(line -> System.out.println(line));
    }
}
