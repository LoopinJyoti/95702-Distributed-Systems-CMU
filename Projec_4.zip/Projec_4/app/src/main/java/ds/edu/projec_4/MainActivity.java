package ds.edu.projec_4;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {

    // Variables for UI components
    private Button button;
    private EditText currencyToBeConverted;
    private EditText currencyConverted;
    private Spinner convertToDropdown;
    private Spinner convertFromDropdown;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI components
        currencyToBeConverted = findViewById(R.id.currency_to_be_converted);
        currencyConverted = findViewById(R.id.currency_converted);
        convertToDropdown = findViewById(R.id.convert_to);
        convertFromDropdown = findViewById(R.id.convert_from);
        button = findViewById(R.id.button);

        // Populate dropdown lists with sample currency values
        String[] currencies = {"USD", "INR", "EUR", "GBP", "JPY", "AUD", "CAD", "CHF", "CNY", "NZD"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_dropdown_item, currencies);

        convertToDropdown.setAdapter(adapter);
        convertFromDropdown.setAdapter(adapter);

        // Add a button click listener (for demonstration, only UI updates for now)
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Retrieve the selected values
                String fromCurrency = convertFromDropdown.getSelectedItem().toString();
                String toCurrency = convertToDropdown.getSelectedItem().toString();
                String amountStr = currencyToBeConverted.getText().toString();

                if (amountStr.isEmpty()) {
                    currencyConverted.setText(getString(R.string.enter_amount_warning));
                    return;
                }

                // For now, show a placeholder result
                double amount = Double.parseDouble(amountStr);
                String result = String.format("Converted %s %.2f to %s", fromCurrency, amount, toCurrency);
                currencyConverted.setText(result);
            }
        });
    }
}
